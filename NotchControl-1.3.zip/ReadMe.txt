NOTCH CONTROL

INSTALL
1. Move "Notch Control" to your Applications folder.
2. Double-click to open it. macOS will say it can't verify it: click Done.
3. Go to System Settings > Privacy & Security, scroll down and click "Open Anyway" next to Notch Control. Confirm.
4. On first launch the app asks for all its permissions, one after another.
5. Move the pointer onto the notch at the top of the screen to open it.

UPDATES
The app updates itself: when a new version is out, a blue arrow appears next to the notch.
Click it and the app updates and reopens, keeping its permissions.

QUIT OR REMOVE
Open the notch, click the gear on the right, then the power button.
To remove it, quit it and move "Notch Control" from Applications to the Trash.

Requires a MacBook with a notch and macOS 14.2 or later.
